let btn0 = document.getElementById("btn0");
let btn1 = document.getElementById("btn1");
let btnC = document.getElementById("btnClr");
let btnEql = document.getElementById("btnEql");
let btnSum = document.getElementById("btnSum");
let btnSub = document.getElementById("btnSub");
let btnMul = document.getElementById("btnMul");
let btnDiv = document.getElementById("btnDiv");
let resDiv = document.getElementById("res");
let opr = ['+','-','*','/'];

btnC.addEventListener("click",()=>{
    resDiv.innerHTML="";
});
btnEql.addEventListener("click",()=>{
    let [oprand1,oprand2]=resDiv.innerHTML.split(/[\+\-\*/]/);
    let opr=resDiv.innerHTML[oprand1.length];
    if(opr==="+")
        resDiv.innerHTML = (Number("0b"+oprand1)+Number("0b"+oprand2)).toString(2);
    else if(opr==="-")
        resDiv.innerHTML = (Number("0b"+oprand1)-Number("0b"+oprand2)).toString(2);
    else if(opr==="*")
        resDiv.innerHTML = (Number("0b"+oprand1)*Number("0b"+oprand2)).toString(2);
    else if(opr==="/")
        resDiv.innerHTML = (Number("0b"+oprand1)/Number("0b"+oprand2)).toString(2);
    else
        console.log("Wrong Operator!!")
});

btn0.addEventListener("click",()=>{
    if(resDiv.innerHTML!=="0")
        resDiv.innerHTML+='0';
});
btn1.addEventListener("click",()=>{
    resDiv.innerHTML+='1';
});

btnSum.addEventListener("click",()=>{
    if(opr.includes(resDiv.innerHTML[resDiv.innerHTML.length-1]))
        resDiv.innerHTML=resDiv.innerHTML.slice(0,resDiv.innerHTML.length-1)+'+';
    else
        resDiv.innerHTML+='+';
});
btnSub.addEventListener("click",()=>{
    if(opr.includes(resDiv.innerHTML[resDiv.innerHTML.length-1]))
        resDiv.innerHTML=resDiv.innerHTML.slice(0,resDiv.innerHTML.length-1)+'-';
    else
        resDiv.innerHTML+='-';
});
btnMul.addEventListener("click",()=>{
    if(opr.includes(resDiv.innerHTML[resDiv.innerHTML.length-1]))
        resDiv.innerHTML=resDiv.innerHTML.slice(0,resDiv.innerHTML.length-1)+'*';
    else
        resDiv.innerHTML+='*';
});
btnDiv.addEventListener("click",()=>{
    if(opr.includes(resDiv.innerHTML[resDiv.innerHTML.length-1]))
        resDiv.innerHTML=resDiv.innerHTML.slice(0,resDiv.innerHTML.length-1)+'/';
    else
        resDiv.innerHTML+='/';
});